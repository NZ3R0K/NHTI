/*
Student Name:  Nathan Hallam
Date: 9/02/2020
Lab Assignment: Lab1-Ch2Intro
Project Name: Lab01_03Proj
Description: Determines the amount of memory that is used by the data types char, int, float, and double.
Limitations or issues:	All the input is hard coded with no opportunity for the user to make changes.
Credits: Not Applicable
*/

#include <iostream>
using namespace std;

int main()
{
	
	// *********** Note to Prof: I found a simpler method online but the code was displayed, so I found a way myself since it felt like cheating. ************
	// Creates namespaces and sets them equal to the data value of their respective data type.
	int charVal, intVal, floatVal, doubleVal;
	charVal = sizeof(char);
	intVal = sizeof(int);
	floatVal = sizeof(float);
	doubleVal = sizeof(double);

	cout << "This program outputs data type sizes:\n\n";

	// Displays the sizes in the command window.
	cout << "Data Type	Size" << endl;
	cout << "---------	----" << endl;
	cout << "char		" << charVal << endl;
	cout << "int		" << intVal << endl;
	cout << "float		" << floatVal << endl;
	cout << "double		" << doubleVal << endl;

	system("pause");
	return 0;

}

/*

Proof:

This program outputs data type sizes:

Data Type       Size
---------       ----
char            1
int             4
float           4
double          8
Press any key to continue . . .

*/