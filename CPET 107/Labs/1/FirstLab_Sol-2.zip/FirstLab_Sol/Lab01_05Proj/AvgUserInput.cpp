/*
Student Name:  Nathan Hallam
Date: 9/02/2020
Lab Assignment: Lab1-Ch2Intro
Project Name: Lab01_05Proj
Description: Calculates the average value of the numbers given by the user
Limitations or issues:	Not Applicable
Credits: C++ From Control Structures through Objects: Eighth Edition
*/

#include <iostream>
using namespace std;

int main()
{

	double val1, val2, val3, val4, val5;
	
	cout << "This program calculates the average of 5 numbers.\n\n";
	
	// User input for the five numbers.
	cout << "Enter five numbers and press the ENTER key after each number:\n";
	cout << "1. ";
	cin >> val1;
	cout << "2. ";
	cin >> val2;
	cout << "3. ";
	cin >> val3;
	cout << "4. ";
	cin >> val4;
	cout << "5. ";
	cin >> val5;
	cout << "\n";
	
	double sum = val1 + val2 + val3 + val4 + val5;
	double avg = sum / 5;

	cout << "Numbers enterd: " << val1 << "	" << val2 <<"	"<< val3 <<"	"<< val4 <<""<<"	"<< val5 << endl << endl;
	cout << "The sum of the five numbers is: " << sum << endl << endl;
	cout << "The average of the five numbers is: " << avg << endl << endl;


	system("pause");
	return 0;

}

/*

Proof:

This program calculates the average of 5 numbers.

Enter five numbers and press the ENTER key after each number:
1. 36
2. 4
3. 10
4. 99
5. 2

Numbers enterd: 36      4       10      99      2

The sum of the five numbers is: 151

The average of the five numbers is: 30.2

Press any key to continue . . .

*/