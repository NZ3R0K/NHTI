/*
Student Name:  Nathan Hallam
Date: 9/02/2020
Lab Assignment: Lab1-Ch2Intro
Project Name: Lab01_02Proj
Description: Calculates the average of a series of values.
Limitations or issues:	All the input is hard coded with no opportunity for the user to make changes.
Credits: Not Applicable
*/

#include <iostream>
using namespace std;

int main()
{
	int val1 = 28;
	int val2 = 32;
	int val3 = 37;
	int val4 = 24;
	int val5 = 33;
	double sum, avgVal;

	sum = val1 + val2 + val3 + val4 + val5; // calculates the sum for five integers given.
	avgVal = sum / 5; // divides the sum of the five given values by the total number of values.

	cout << "This program calculates the average of 5 numbers." << endl << endl;

	// Displays the calculations done in the command window.
	cout << "The sum of the five numbers is: " << sum << endl;
	cout << "The average og the five numbers is: " << avgVal << endl;

	system("pause");
	return 0;

}


/*
Proof:

This program calculates the average of 5 numbers.

The sum of the five numbers is: 154
The average og the five numbers is: 30.8
Press any key to continue . . .

*/