/*
Student Name:  Nathan Hallam
Date: 9/02/2020
Lab Assignment: Lab1-Ch2Intro
Project Name: Lab01_04Proj
Description: Calculates and displays the distance the car can travel on one tank of gas.
Limitations or issues:	All the input is hard coded with no opportunity for the user to make changes.
Credits: Not Applicable
*/

#include <iostream>
using namespace std;

int main()
{

	int gas = 20;
	double townMiles = 21.5;
	double highwayMiles = 26.8;
	int avgTownMiles = gas * townMiles; // Averages mpg in town.
	int avgHighwayMiles = gas * highwayMiles; // Averages mpg on the highway.

	// Displays statistics for the cars mpg.
	cout << "This program calculates miles per gallon for a present number of gallons.\n\n";
	cout << "A car has a " << gas << " gallon fuel tank.\n";
	cout << "This car gets " << townMiles << " miles per gallon in the city\n";
	cout << "and " << highwayMiles << " miles per gallon on the highway.  That means:\n\n";

	// Displays the average mpg of the vehicle
	cout << "In town, the car can average a distance of\n";
	cout << avgTownMiles << " miles on a full tank.\n\n";

	cout << "On the highway, the car can average a distance of\n";
	cout << avgHighwayMiles << " miles on a full tank.\n\n";

	system("pause");
	return 0;

}

/*

Proof:

This program calculates miles per gallon for a present number of gallons.

A car has a 20 gallon fuel tank.
This car gets 21.5 miles per gallon in the city
and 26.8 miles per gallon on the highway.  That means:

In town, the car can average a distance of
430 miles on a full tank.

On the highway, the car can average a distance of
536 miles on a full tank.

Press any key to continue . . .

*/